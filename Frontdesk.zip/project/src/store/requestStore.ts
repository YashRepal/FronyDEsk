import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { HelpRequest, RequestStatus } from '../types';

interface RequestState {
  requests: HelpRequest[];
  createRequest: (question: string, customerPhone: string) => string;
  resolveRequest: (id: string, answer: string) => void;
  timeoutRequest: (id: string) => void;
  getRequest: (id: string) => HelpRequest | undefined;
  getPendingRequests: () => HelpRequest[];
  getResolvedRequests: () => HelpRequest[];
  getTimeoutRequests: () => HelpRequest[];
}

const DEFAULT_TIMEOUT = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

// Store to manage help requests
export const useRequestStore = create<RequestState>((set, get) => ({
  requests: [],
  
  createRequest: (question, customerPhone) => {
    const id = uuidv4();
    const now = new Date();
    const timeoutAt = new Date(now.getTime() + DEFAULT_TIMEOUT).toISOString();
    
    const newRequest: HelpRequest = {
      id,
      question,
      customerPhone,
      timestamp: now.toISOString(),
      status: 'pending',
      timeoutAt
    };
    
    set(state => ({
      requests: [...state.requests, newRequest]
    }));
    
    // Schedule timeout for this request
    setTimeout(() => {
      const request = get().getRequest(id);
      if (request && request.status === 'pending') {
        get().timeoutRequest(id);
      }
    }, DEFAULT_TIMEOUT);
    
    console.log(`Supervisor notification: New help request from ${customerPhone}: "${question}"`);
    
    return id;
  },
  
  resolveRequest: (id, answer) => {
    set(state => ({
      requests: state.requests.map(request => 
        request.id === id 
          ? { 
              ...request, 
              status: 'resolved' as RequestStatus, 
              answer, 
              respondedAt: new Date().toISOString() 
            } 
          : request
      )
    }));
    
    const request = get().getRequest(id);
    if (request) {
      console.log(`Customer notification: Text sent to ${request.customerPhone}: "Thanks for your question. ${answer}"`);
    }
  },
  
  timeoutRequest: (id) => {
    set(state => ({
      requests: state.requests.map(request => 
        request.id === id 
          ? { ...request, status: 'timeout' as RequestStatus } 
          : request
      )
    }));
  },
  
  getRequest: (id) => {
    return get().requests.find(request => request.id === id);
  },
  
  getPendingRequests: () => {
    return get().requests.filter(request => request.status === 'pending');
  },
  
  getResolvedRequests: () => {
    return get().requests.filter(request => request.status === 'resolved');
  },
  
  getTimeoutRequests: () => {
    return get().requests.filter(request => request.status === 'timeout');
  }
}));