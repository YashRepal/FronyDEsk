import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { KnowledgeEntry } from '../types';
import { salonInfo } from '../data/salonInfo';

type KnowledgeState = {
  entries: KnowledgeEntry[];
  addEntry: (question: string, answer: string) => void;
  incrementUsage: (id: string) => void;
  searchKnowledge: (query: string) => KnowledgeEntry[];
  getKnowledgeAnswer: (question: string) => string | null;
};

// Initial knowledge entries based on salon information
const createInitialKnowledge = (): KnowledgeEntry[] => {
  const now = new Date().toISOString();
  
  return [
    {
      id: uuidv4(),
      question: "What are the salon's hours?",
      answer: `Our hours are: ${Object.entries(salonInfo.hours).map(([day, hours]) => `${day}: ${hours}`).join(', ')}`,
      createdAt: now,
      updatedAt: now,
      usageCount: 0
    },
    {
      id: uuidv4(),
      question: "What services do you offer?",
      answer: `We offer various services including: ${salonInfo.services.map(s => `${s.name} (${s.price})`).join(', ')}`,
      createdAt: now,
      updatedAt: now,
      usageCount: 0
    },
    {
      id: uuidv4(),
      question: "How can I book an appointment?",
      answer: `You can book an appointment by calling us at ${salonInfo.phone} or visiting our website.`,
      createdAt: now,
      updatedAt: now,
      usageCount: 0
    },
    {
      id: uuidv4(),
      question: "Where are you located?",
      answer: `We are located at ${salonInfo.address}.`,
      createdAt: now,
      updatedAt: now,
      usageCount: 0
    },
    {
      id: uuidv4(),
      question: "Who are your stylists?",
      answer: `Our stylists include: ${salonInfo.stylists.map(s => `${s.name} (specializes in ${s.specialties.join(', ')})`).join('; ')}`,
      createdAt: now,
      updatedAt: now,
      usageCount: 0
    }
  ];
};

export const useKnowledgeStore = create<KnowledgeState>((set, get) => ({
  entries: createInitialKnowledge(),
  
  addEntry: (question, answer) => {
    const now = new Date().toISOString();
    
    // Check if we already have a similar question
    const similarEntry = get().searchKnowledge(question)[0];
    
    if (similarEntry) {
      // Update existing entry
      set(state => ({
        entries: state.entries.map(entry => 
          entry.id === similarEntry.id 
            ? { 
                ...entry, 
                answer, 
                updatedAt: now,
                usageCount: entry.usageCount + 1 
              } 
            : entry
        )
      }));
    } else {
      // Create new entry
      const newEntry: KnowledgeEntry = {
        id: uuidv4(),
        question,
        answer,
        createdAt: now,
        updatedAt: now,
        usageCount: 1
      };
      
      set(state => ({
        entries: [...state.entries, newEntry]
      }));
    }
  },
  
  incrementUsage: (id) => {
    set(state => ({
      entries: state.entries.map(entry => 
        entry.id === id 
          ? { ...entry, usageCount: entry.usageCount + 1 } 
          : entry
      )
    }));
  },
  
  searchKnowledge: (query) => {
    const normalizedQuery = query.toLowerCase().trim();
    
    return get().entries.filter(entry => 
      entry.question.toLowerCase().includes(normalizedQuery) ||
      entry.answer.toLowerCase().includes(normalizedQuery)
    ).sort((a, b) => b.usageCount - a.usageCount);
  },
  
  getKnowledgeAnswer: (question) => {
    const results = get().searchKnowledge(question);
    
    if (results.length > 0) {
      const bestMatch = results[0];
      get().incrementUsage(bestMatch.id);
      return bestMatch.answer;
    }
    
    return null;
  }
}));