import { SalonInfo } from '../types';

export const salonInfo: SalonInfo = {
  name: "Elegance Hair & Beauty",
  address: "123 Style Street, Fashion City, FC 12345",
  phone: "555-123-4567",
  hours: {
    "Monday": "9:00 AM - 7:00 PM",
    "Tuesday": "9:00 AM - 7:00 PM",
    "Wednesday": "9:00 AM - 7:00 PM",
    "Thursday": "9:00 AM - 8:00 PM",
    "Friday": "9:00 AM - 8:00 PM",
    "Saturday": "9:00 AM - 6:00 PM",
    "Sunday": "10:00 AM - 4:00 PM"
  },
  services: [
    {
      name: "Women's Haircut",
      price: "$45-65",
      duration: "45 minutes"
    },
    {
      name: "Men's Haircut",
      price: "$30-45",
      duration: "30 minutes"
    },
    {
      name: "Hair Coloring",
      price: "$85-150",
      duration: "2 hours"
    },
    {
      name: "Highlights",
      price: "$120-180",
      duration: "2-3 hours"
    },
    {
      name: "Blowout",
      price: "$35",
      duration: "30 minutes"
    },
    {
      name: "Manicure",
      price: "$25",
      duration: "30 minutes"
    },
    {
      name: "Pedicure",
      price: "$40",
      duration: "45 minutes"
    },
    {
      name: "Facial",
      price: "$75",
      duration: "60 minutes"
    }
  ],
  stylists: [
    {
      name: "Sophia Chen",
      specialties: ["Color Specialist", "Curly Hair"],
      availability: ["Monday", "Tuesday", "Thursday", "Friday"]
    },
    {
      name: "James Rodriguez",
      specialties: ["Men's Styling", "Fades", "Beard Grooming"],
      availability: ["Tuesday", "Wednesday", "Friday", "Saturday"]
    },
    {
      name: "Emma Wilson",
      specialties: ["Balayage", "Wedding Styles", "Extensions"],
      availability: ["Wednesday", "Thursday", "Friday", "Saturday"]
    },
    {
      name: "Michael Taylor",
      specialties: ["Precision Cuts", "Textured Hair", "Color Correction"],
      availability: ["Monday", "Thursday", "Friday", "Sunday"]
    }
  ]
};