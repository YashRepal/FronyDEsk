import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AppLayout from './components/layout/AppLayout';
import Dashboard from './pages/Dashboard';
import RequestsPage from './pages/RequestsPage';
import KnowledgeBasePage from './pages/KnowledgeBasePage';
import AgentSimulatorPage from './pages/AgentSimulatorPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="requests" element={<RequestsPage />} />
          <Route path="knowledge" element={<KnowledgeBasePage />} />
          <Route path="agent-simulator" element={<AgentSimulatorPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;