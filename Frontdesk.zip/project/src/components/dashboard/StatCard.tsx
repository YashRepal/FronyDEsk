import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  iconColor?: string;
  description?: string;
  trend?: {
    value: number;
    label: string;
  };
  trendDirection?: 'up' | 'down' | 'neutral';
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon: Icon,
  iconColor = 'text-primary',
  description,
  trend,
  trendDirection = 'neutral'
}) => {
  const trendClasses = {
    up: 'text-success',
    down: 'text-error',
    neutral: 'text-secondary'
  };
  
  return (
    <div className="card hover:shadow-md">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-sm font-medium text-slate-500">{title}</h3>
          <p className="text-2xl font-semibold mt-1 text-slate-800">{value}</p>
        </div>
        <div className={cn("p-2 rounded-full bg-opacity-10", iconColor)}>
          <Icon className={cn("w-5 h-5", iconColor)} />
        </div>
      </div>
      
      {description && (
        <p className="text-sm text-slate-600 mt-1">{description}</p>
      )}
      
      {trend && (
        <div className={`mt-3 text-sm ${trendClasses[trendDirection]}`}>
          {trendDirection === 'up' && '↑ '}
          {trendDirection === 'down' && '↓ '}
          {trend.value}% {trend.label}
        </div>
      )}
    </div>
  );
};

export default StatCard;