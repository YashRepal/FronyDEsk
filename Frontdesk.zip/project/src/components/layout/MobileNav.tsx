import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  MessageSquareText, 
  GraduationCap, 
  PhoneCall 
} from 'lucide-react';

const navItems = [
  { to: '/', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
  { to: '/requests', label: 'Requests', icon: <MessageSquareText className="w-5 h-5" /> },
  { to: '/knowledge', label: 'Knowledge', icon: <GraduationCap className="w-5 h-5" /> },
  { to: '/agent-simulator', label: 'Simulator', icon: <PhoneCall className="w-5 h-5" /> },
];

const MobileNav = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-10">
      <div className="grid grid-cols-4 h-16">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => 
              `flex flex-col items-center justify-center py-1 ${
                isActive ? 'text-primary' : 'text-secondary hover:text-foreground'
              }`
            }
          >
            <span>{item.icon}</span>
            <span className="text-xs mt-1">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </div>
  );
};

export default MobileNav;