import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  MessageSquareText, 
  GraduationCap, 
  PhoneCall 
} from 'lucide-react';

const navItems = [
  { to: '/', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
  { to: '/requests', label: 'Help Requests', icon: <MessageSquareText className="w-5 h-5" /> },
  { to: '/knowledge', label: 'Knowledge Base', icon: <GraduationCap className="w-5 h-5" /> },
  { to: '/agent-simulator', label: 'Call Simulator', icon: <PhoneCall className="w-5 h-5" /> },
];

const Sidebar = () => {
  return (
    <div className="h-full py-6 px-3">
      <nav className="space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => 
              `flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive 
                ? 'bg-primary/10 text-primary' 
                : 'text-foreground hover:bg-slate-100'
              }`
            }
          >
            <span className="mr-3">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;