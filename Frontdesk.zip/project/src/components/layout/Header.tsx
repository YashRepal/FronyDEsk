import { Phone, Headphones } from 'lucide-react';

const Header = () => {
  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 z-10">
      <div className="h-full mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Headphones className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg">Frontdesk AI</span>
        </div>
        
        <div className="flex items-center">
          <div className="flex items-center space-x-1">
            <Phone className="h-4 w-4 text-success" />
            <span className="text-sm font-medium text-success">AI Agent Online</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;