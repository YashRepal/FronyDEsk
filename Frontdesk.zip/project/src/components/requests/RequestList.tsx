import { HelpRequest } from '../../types';
import RequestCard from './RequestCard';

interface RequestListProps {
  requests: HelpRequest[];
  emptyMessage: string;
}

const RequestList: React.FC<RequestListProps> = ({ requests, emptyMessage }) => {
  if (requests.length === 0) {
    return (
      <div className="text-center py-8 text-slate-500">
        <p>{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {requests.map(request => (
        <RequestCard key={request.id} request={request} />
      ))}
    </div>
  );
};

export default RequestList;