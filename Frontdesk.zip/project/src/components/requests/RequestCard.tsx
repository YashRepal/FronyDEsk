import { useState } from 'react';
import { format } from 'date-fns';
import { MessageSquareText, Clock, Check, XCircle } from 'lucide-react';
import { HelpRequest } from '../../types';
import { useRequestStore } from '../../store/requestStore';
import { useKnowledgeStore } from '../../store/knowledgeStore';

interface RequestCardProps {
  request: HelpRequest;
}

const RequestCard: React.FC<RequestCardProps> = ({ request }) => {
  const [answer, setAnswer] = useState('');
  const resolveRequest = useRequestStore(state => state.resolveRequest);
  const addKnowledgeEntry = useKnowledgeStore(state => state.addEntry);

  const handleResolve = () => {
    if (!answer.trim()) return;
    
    resolveRequest(request.id, answer);
    addKnowledgeEntry(request.question, answer);
    setAnswer('');
  };

  // Format the timestamp
  const formattedTime = format(new Date(request.timestamp), 'MMM d, yyyy h:mm a');

  // Determine the status badge style
  const getBadgeClass = () => {
    switch (request.status) {
      case 'pending': return 'badge-pending';
      case 'resolved': return 'badge-resolved';
      case 'timeout': return 'badge-timeout';
      default: return '';
    }
  };

  // Get the status icon
  const getStatusIcon = () => {
    switch (request.status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'resolved': return <Check className="w-4 h-4" />;
      case 'timeout': return <XCircle className="w-4 h-4" />;
      default: return null;
    }
  };

  return (
    <div className="card hover:shadow-md animate-fade-in">
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center">
          <MessageSquareText className="w-5 h-5 text-primary mr-2" />
          <h3 className="font-medium text-card-foreground">Customer Question</h3>
        </div>
        <span className={`badge ${getBadgeClass()} flex items-center space-x-1`}>
          {getStatusIcon()}
          <span>{request.status}</span>
        </span>
      </div>
      
      <p className="text-slate-700 mb-2">{request.question}</p>
      
      <div className="flex flex-wrap items-center text-xs text-slate-500 mb-4">
        <span className="mr-4">From: {request.customerPhone}</span>
        <span>Received: {formattedTime}</span>
      </div>

      {request.status === 'resolved' && (
        <div className="mt-4 p-3 bg-success/5 rounded-md border border-success/20">
          <h4 className="font-medium text-success mb-1 flex items-center">
            <Check className="w-4 h-4 mr-1" /> Response
          </h4>
          <p className="text-slate-700">{request.answer}</p>
          {request.respondedAt && (
            <p className="text-xs text-slate-500 mt-1">
              Responded: {format(new Date(request.respondedAt), 'MMM d, yyyy h:mm a')}
            </p>
          )}
        </div>
      )}

      {request.status === 'pending' && (
        <div className="mt-4">
          <textarea
            className="input w-full min-h-[100px] mb-3"
            placeholder="Type your response here..."
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
          />
          <button 
            className="btn btn-primary w-full"
            onClick={handleResolve}
            disabled={!answer.trim()}
          >
            Submit Response
          </button>
        </div>
      )}

      {request.status === 'timeout' && (
        <div className="mt-4 p-3 bg-error/5 rounded-md border border-error/20">
          <h4 className="font-medium text-error mb-1 flex items-center">
            <XCircle className="w-4 h-4 mr-1" /> Request Timed Out
          </h4>
          <p className="text-slate-700">This request was not answered in time.</p>
        </div>
      )}
    </div>
  );
};

export default RequestCard;