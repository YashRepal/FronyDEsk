import { useState } from 'react';
import { PhoneCall, Send } from 'lucide-react';
import { simulateIncomingCall } from '../../services/agentService';

const CallSimulator: React.FC = () => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [question, setQuestion] = useState('');
  const [callHistory, setCallHistory] = useState<Array<{
    id: number;
    phoneNumber: string;
    question: string;
    timestamp: string;
  }>>([]);
  
  const handleSimulateCall = () => {
    if (!phoneNumber.trim() || !question.trim()) return;
    
    // Log the call to history
    setCallHistory(prev => [
      {
        id: Date.now(),
        phoneNumber,
        question,
        timestamp: new Date().toISOString()
      },
      ...prev
    ]);
    
    // Simulate the actual call
    simulateIncomingCall(question, phoneNumber);
    
    // Clear the inputs
    setQuestion('');
  };
  
  return (
    <div className="card">
      <div className="flex items-center mb-4">
        <PhoneCall className="w-5 h-5 text-primary mr-2" />
        <h2 className="text-xl font-medium">Call Simulator</h2>
      </div>
      
      <div className="space-y-4 mb-6">
        <div>
          <label htmlFor="phoneNumber" className="block text-sm font-medium text-slate-700 mb-1">
            Customer Phone Number
          </label>
          <input
            id="phoneNumber"
            type="tel"
            className="input w-full"
            placeholder="555-123-4567"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
          />
        </div>
        
        <div>
          <label htmlFor="question" className="block text-sm font-medium text-slate-700 mb-1">
            Customer Question
          </label>
          <textarea
            id="question"
            className="input w-full min-h-[100px]"
            placeholder="Enter customer question here..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
        </div>
        
        <button
          className="btn btn-primary w-full flex items-center justify-center"
          onClick={handleSimulateCall}
          disabled={!phoneNumber.trim() || !question.trim()}
        >
          <Send className="w-4 h-4 mr-2" />
          Simulate Call
        </button>
      </div>
      
      {callHistory.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-slate-700 mb-2">Recent Simulated Calls</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {callHistory.map(call => (
              <div 
                key={call.id} 
                className="p-3 bg-slate-50 rounded-md border border-slate-200"
              >
                <p className="text-sm font-medium">{call.phoneNumber}</p>
                <p className="text-sm text-slate-700">{call.question}</p>
                <p className="text-xs text-slate-500">
                  {new Date(call.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CallSimulator;