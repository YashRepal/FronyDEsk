import { format } from 'date-fns';
import { BookOpen, RefreshCw } from 'lucide-react';
import { KnowledgeEntry } from '../../types';

interface KnowledgeCardProps {
  entry: KnowledgeEntry;
}

const KnowledgeCard: React.FC<KnowledgeCardProps> = ({ entry }) => {
  const formattedDate = format(new Date(entry.updatedAt), 'MMM d, yyyy');
  
  return (
    <div className="card hover:shadow-md animate-fade-in">
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center">
          <BookOpen className="w-5 h-5 text-primary mr-2" />
          <h3 className="font-medium text-card-foreground">Knowledge Entry</h3>
        </div>
        <span className="badge bg-primary/10 text-primary flex items-center">
          <span>Used {entry.usageCount} times</span>
        </span>
      </div>
      
      <h4 className="font-medium text-slate-800 mb-2">{entry.question}</h4>
      <p className="text-slate-700 mb-4">{entry.answer}</p>
      
      <div className="flex flex-wrap items-center text-xs text-slate-500">
        <span className="mr-4 flex items-center">
          <RefreshCw className="w-3 h-3 mr-1" /> Updated: {formattedDate}
        </span>
      </div>
    </div>
  );
};

export default KnowledgeCard;