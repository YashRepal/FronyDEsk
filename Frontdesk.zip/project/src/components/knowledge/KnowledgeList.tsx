import { useState } from 'react';
import { Search } from 'lucide-react';
import { KnowledgeEntry } from '../../types';
import KnowledgeCard from './KnowledgeCard';

interface KnowledgeListProps {
  entries: KnowledgeEntry[];
}

const KnowledgeList: React.FC<KnowledgeListProps> = ({ entries }) => {
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredEntries = searchQuery.trim()
    ? entries.filter(entry => 
        entry.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.answer.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : entries;
  
  // Sort by usage count (most used first)
  const sortedEntries = [...filteredEntries].sort((a, b) => b.usageCount - a.usageCount);
  
  return (
    <div>
      <div className="mb-6 relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="input pl-10 w-full"
          placeholder="Search knowledge base..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      
      {sortedEntries.length === 0 ? (
        <div className="text-center py-8 text-slate-500">
          <p>No knowledge entries found.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedEntries.map(entry => (
            <KnowledgeCard key={entry.id} entry={entry} />
          ))}
        </div>
      )}
    </div>
  );
};

export default KnowledgeList;