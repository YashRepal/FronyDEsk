// Request status types
export type RequestStatus = 'pending' | 'resolved' | 'timeout';

// Request model
export interface HelpRequest {
  id: string;
  question: string;
  customerPhone: string;
  timestamp: string;
  status: RequestStatus;
  answer?: string;
  respondedAt?: string;
  timeoutAt?: string;
}

// Knowledge base entry
export interface KnowledgeEntry {
  id: string;
  question: string;
  answer: string;
  createdAt: string;
  updatedAt: string;
  usageCount: number;
}

// Salon information for the AI agent
export interface SalonInfo {
  name: string;
  address: string;
  phone: string;
  hours: Record<string, string>;
  services: Array<{
    name: string;
    price: string;
    duration: string;
  }>;
  stylists: Array<{
    name: string;
    specialties: string[];
    availability: string[];
  }>;
}