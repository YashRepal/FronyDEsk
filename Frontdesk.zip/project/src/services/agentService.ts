import { useKnowledgeStore } from '../store/knowledgeStore';
import { useRequestStore } from '../store/requestStore';

export const processAgentQuery = (question: string, customerPhone: string): { 
  canAnswer: boolean; 
  answer?: string;
  requestId?: string;
} => {
  const answer = useKnowledgeStore.getState().getKnowledgeAnswer(question);
  
  if (answer) {
    return {
      canAnswer: true,
      answer
    };
  }
  
  // If we don't know the answer, create a help request
  const requestId = useRequestStore.getState().createRequest(question, customerPhone);
  
  return {
    canAnswer: false,
    requestId
  };
};

export const simulateIncomingCall = (question: string, customerPhone: string): void => {
  console.log(`Incoming call from ${customerPhone}`);
  console.log(`Customer question: "${question}"`);
  
  const result = processAgentQuery(question, customerPhone);
  
  if (result.canAnswer) {
    console.log(`AI Agent responding: "${result.answer}"`);
  } else {
    console.log(`AI Agent: "Let me check with my supervisor and get back to you."`);
  }
};