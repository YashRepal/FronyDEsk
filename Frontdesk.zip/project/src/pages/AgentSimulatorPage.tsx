import CallSimulator from '../components/simulator/CallSimulator';

const AgentSimulatorPage = () => {
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold mb-6">Call Simulator</h1>
      
      <div className="bg-primary/5 border border-primary/20 rounded-md p-4 mb-6">
        <h2 className="text-lg font-medium text-primary mb-2">Testing the AI Agent</h2>
        <p className="text-slate-700">
          Use this simulator to test how the AI agent responds to customer questions. If the agent knows 
          the answer, it will respond immediately. If not, it will escalate to a supervisor and create a help request.
        </p>
      </div>
      
      <CallSimulator />
    </div>
  );
};

export default AgentSimulatorPage;