import { useKnowledgeStore } from '../store/knowledgeStore';
import KnowledgeList from '../components/knowledge/KnowledgeList';

const KnowledgeBasePage = () => {
  const knowledgeEntries = useKnowledgeStore(state => state.entries);
  
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold mb-6">Knowledge Base</h1>
      
      <div className="bg-primary/5 border border-primary/20 rounded-md p-4 mb-6">
        <h2 className="text-lg font-medium text-primary mb-2">How the Knowledge Base Works</h2>
        <p className="text-slate-700">
          When a supervisor answers a customer question, the response is automatically added to the 
          knowledge base. The AI agent uses this information to answer similar questions in the future 
          without supervisor intervention.
        </p>
      </div>
      
      <KnowledgeList entries={knowledgeEntries} />
    </div>
  );
};

export default KnowledgeBasePage;