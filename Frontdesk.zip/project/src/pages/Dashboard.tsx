import { useEffect, useState } from 'react';
import { 
  MessageSquare, 
  CheckCircle, 
  Clock, 
  BookOpen,
  Users,
  PhoneCall
} from 'lucide-react';
import StatCard from '../components/dashboard/StatCard';
import RequestList from '../components/requests/RequestList';
import { useRequestStore } from '../store/requestStore';
import { useKnowledgeStore } from '../store/knowledgeStore';

const Dashboard = () => {
  const pendingRequests = useRequestStore(state => state.getPendingRequests());
  const resolvedRequests = useRequestStore(state => state.getResolvedRequests());
  const timeoutRequests = useRequestStore(state => state.getTimeoutRequests());
  const knowledgeEntries = useKnowledgeStore(state => state.entries);
  
  // Simulated metrics
  const [metrics, setMetrics] = useState({
    totalCalls: 0,
    callsHandledByAI: 0,
    avgResponseTime: 0
  });
  
  // Update simulated metrics whenever resolved requests change
  useEffect(() => {
    const totalCalls = pendingRequests.length + resolvedRequests.length + timeoutRequests.length;
    const callsHandledByAI = totalCalls - pendingRequests.length - timeoutRequests.length;
    const avgResponseTime = resolvedRequests.length > 0 ? 
      Math.floor(Math.random() * 120) + 30 : 0; // Random time between 30-150 minutes
    
    setMetrics({
      totalCalls,
      callsHandledByAI,
      avgResponseTime
    });
  }, [pendingRequests.length, resolvedRequests.length, timeoutRequests.length]);
  
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          <StatCard 
            title="Total Help Requests" 
            value={metrics.totalCalls}
            icon={MessageSquare}
            iconColor="text-primary"
          />
          <StatCard 
            title="Resolved Requests" 
            value={resolvedRequests.length}
            icon={CheckCircle}
            iconColor="text-success"
          />
          <StatCard 
            title="Pending Requests" 
            value={pendingRequests.length}
            icon={Clock}
            iconColor="text-warning"
          />
          <StatCard 
            title="Knowledge Base Entries" 
            value={knowledgeEntries.length}
            icon={BookOpen}
            iconColor="text-secondary"
          />
          <StatCard 
            title="AI Resolution Rate" 
            value={`${metrics.callsHandledByAI > 0 ? 
              Math.round((metrics.callsHandledByAI / metrics.totalCalls) * 100) : 0}%`}
            icon={Users}
            iconColor="text-indigo-500"
            trend={{
              value: 12,
              label: "this week"
            }}
            trendDirection="up"
          />
          <StatCard 
            title="Avg. Response Time" 
            value={`${metrics.avgResponseTime} min`}
            icon={PhoneCall}
            iconColor="text-rose-500"
          />
        </div>
      </div>
      
      {pendingRequests.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Pending Requests</h2>
          <RequestList
            requests={pendingRequests}
            emptyMessage="No pending requests."
          />
        </div>
      )}
      
      {resolvedRequests.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Recent Resolved Requests</h2>
          <RequestList
            requests={resolvedRequests.slice(0, 3)} // Show only the 3 most recent
            emptyMessage="No resolved requests."
          />
          {resolvedRequests.length > 3 && (
            <div className="mt-4 text-center">
              <a href="/requests" className="text-primary hover:underline">
                View all {resolvedRequests.length} resolved requests
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Dashboard;