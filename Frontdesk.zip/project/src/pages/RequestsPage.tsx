import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/Tabs';
import RequestList from '../components/requests/RequestList';
import { useRequestStore } from '../store/requestStore';

const RequestsPage = () => {
  const [activeTab, setActiveTab] = useState('pending');
  const pendingRequests = useRequestStore(state => state.getPendingRequests());
  const resolvedRequests = useRequestStore(state => state.getResolvedRequests());
  const timeoutRequests = useRequestStore(state => state.getTimeoutRequests());
  
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold mb-6">Help Requests</h1>
      
      <div className="mb-6">
        <div className="border-b border-slate-200">
          <nav className="flex space-x-8" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('pending')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'pending'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              }`}
            >
              Pending ({pendingRequests.length})
            </button>
            <button
              onClick={() => setActiveTab('resolved')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'resolved'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              }`}
            >
              Resolved ({resolvedRequests.length})
            </button>
            <button
              onClick={() => setActiveTab('timeout')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'timeout'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              }`}
            >
              Timed Out ({timeoutRequests.length})
            </button>
          </nav>
        </div>
      </div>
      
      <div className="mt-6">
        {activeTab === 'pending' && (
          <RequestList
            requests={pendingRequests}
            emptyMessage="No pending requests."
          />
        )}
        
        {activeTab === 'resolved' && (
          <RequestList
            requests={resolvedRequests}
            emptyMessage="No resolved requests."
          />
        )}
        
        {activeTab === 'timeout' && (
          <RequestList
            requests={timeoutRequests}
            emptyMessage="No timed out requests."
          />
        )}
      </div>
    </div>
  );
};

export default RequestsPage;